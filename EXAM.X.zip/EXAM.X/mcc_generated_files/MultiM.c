/*
 * File:   MultiM.c
 * Author: Adam Zaghloul, Guy Arnold
 *
 * Created on April 13, 2026, 8:00 PM
 *
 * Multimetre numerique ? PIC18F46K22
 *   mode 0 : veille     (affichage eteint)
 *   mode 1 : voltmetre  (SW1 -> INT0)
 *   mode 2 : ohmetre    (SW2 -> INT1)
 *   mode 3 : hold       (SW3 -> INT2, gel 3 s puis veille)
 */

#include "mcc.h"
#include "MultiM.h"

/* ==========================================================================
 * SEGMENT TABLE
 * 7-segment codes (common-anode, active-low logic), index 0-9.
 * ========================================================================== */
uint8_t TabSeg[] = {0x40, 0x79, 0x24, 0x30, 0x19,
                    0x12, 0x02, 0x78, 0x00, 0x10};

/* ==========================================================================
 * GLOBAL STATE
 * ========================================================================== */

/* Active mode ? written by external-interrupt ISRs, read everywhere */
volatile uint8_t mode = 0;

/* Hold countdown ? decremented every timer ISR tick inside Multiplexage() */
volatile uint16_t hold_counter = 0;

/* Display digits: most significant (H), middle (M), least significant (L) */
int digit_H = 0, digit_M = 0, digit_L = 0;

/* Decimal-point position: 0 = after digit H, 1 = after digit M */
int dp_position = 0;

/* Ohmmeter intermediates */
uint16_t adc_raw_ohm = 0;      /* raw 10-bit ADC reading on AN0 */
float    v_divider   = 0.0f;   /* voltage at the divider midpoint (V) */
float    res_kohm    = 0.0f;   /* resistance in kohms (display value) */

/* Voltmeter intermediates */
float adc_raw_volt = 0.0f;     /* raw ADC reading cast to float */
float v_measured   = 0.0f;     /* scaled true voltage (V) */


/* ==========================================================================
 * DISPLAY LAYER ? PRIMITIVES
 * ========================================================================== */

/* --------------------------------------------------------------------------
 * digitSelect()
 * Drive LATE to enable exactly one digit (active-low).
 *   0 -> most significant digit  (bit 0 low  -> 0xFE)
 *   1 -> middle digit            (bit 1 low  -> 0xFD)
 *   2 -> least significant digit (bit 2 low  -> 0xFB)
 * ------------------------------------------------------------------------ */
void digitSelect(int digit)
{
    if      (digit == 0) LATE = 0xFE;
    else if (digit == 1) LATE = 0xFD;
    else if (digit == 2) LATE = 0xFB;
}


/* --------------------------------------------------------------------------
 * Multiplexage()
 * Called exclusively from the TMR0 ISR (tmr0.c -> TMR0_CallBack).
 * Each call activates one digit in sequence: H -> M -> L -> H -> ...
 *
 * Hold countdown:
 *   When mode == 3, hold_counter is decremented on every ISR tick.
 *   When it reaches 0 the system transitions to Mode Veille (mode = 0).
 *   HOLD_TICKS (defined in MultiM.h) must equal 3000 / TMR0_period_ms.
 *   Example: TMR0 period = 2 ms  ->  HOLD_TICKS = 1500.
 *
 * The decimal point (bit 7 low = ON) follows dp_position.
 * ------------------------------------------------------------------------ */
void Multiplexage(void)
{
    static uint8_t digit_idx = 0;

    /* --- Hold countdown ------------------------------------------------- */
    if (mode == 3)
    {
        if (hold_counter > 0)
        {
            hold_counter--;
        }
        else
        {
            /* 3 seconds elapsed: blank display and enter veille */
            mode = 0;
            MODE_VEILLE();
            digit_idx = 0;
            return;
        }
        /* While counting down, keep the frozen digits visible (fall through) */
    }

    /* --- Veille: display fully off -------------------------------------- */
    if (mode == 0)
    {
        LATE = 0xFF;
        LATC = 0xFF;
        return;
    }

    /* --- Normal multiplexage -------------------------------------------- */

    /* Blank outputs before switching to avoid ghosting */
    LATE = 0xFF;
    LATC = 0xFF;

    if (digit_idx == 0)
    {
        /* Digit H: decimal point ON when dp_position == 0  ->  X.XX */
        LATC = (dp_position == 0) ? (TabSeg[digit_H] & 0x7F)
                                  : (TabSeg[digit_H] | 0x80);
        digitSelect(0);
    }
    else if (digit_idx == 1)
    {
        /* Digit M: decimal point ON when dp_position == 1  ->  XX.X */
        LATC = (dp_position == 1) ? (TabSeg[digit_M] & 0x7F)
                                  : (TabSeg[digit_M] | 0x80);
        digitSelect(1);
    }
    else
    {
        /* Digit L (units): decimal point never shown here */
        LATC = TabSeg[digit_L] | 0x80;
        digitSelect(2);
    }

    if (++digit_idx >= 3)
        digit_idx = 0;
}


/* ==========================================================================
 * DISPLAY LAYER ? DIGIT DECOMPOSITION HELPERS
 * ========================================================================== */

/* --------------------------------------------------------------------------
 * Affichage_sur_chaque_digit()
 * Split res_kohm (in kohms) into three display digits.
 *   res_kohm <  10 k? : format X.XX  (e.g. 4.20  -> H=4, M=2, L=0)
 *   res_kohm < 100 k? : format XX.X  (e.g. 12.3  -> H=1, M=2, L=3)
 * ------------------------------------------------------------------------ */
void Affichage_sur_chaque_digit(void)
{
    int tmp;

    if (res_kohm < 10.0f)
    {
        tmp     = (int)(res_kohm * 100.0f + 0.5f);
        digit_H = tmp / 100;
        digit_M = (tmp / 10) % 10;
        digit_L = tmp % 10;
    }
    else if (res_kohm < 100.0f)
    {
        tmp     = (int)(res_kohm * 10.0f + 0.5f);
        digit_H = tmp / 100;
        digit_M = (tmp / 10) % 10;
        digit_L = tmp % 10;
    }
}


/* --------------------------------------------------------------------------
 * Position_Point_Decimal()
 * Select decimal-point position based on the magnitude of res_kohm.
 *   < 10 k?  -> point after digit H (X.XX)
 *   >= 10 k? -> point after digit M (XX.X)
 * ------------------------------------------------------------------------ */
void Position_Point_Decimal(void)
{
    dp_position = (res_kohm < 10.0f) ? 0 : 1;
}


/* --------------------------------------------------------------------------
 * Affichage_voltage()
 * Split v_measured (in volts) into three display digits.
 *   v_measured <  10 V : format X.XX  (e.g. 5.67 -> H=5, M=6, L=7)
 *   v_measured >= 10 V : format XX.X  (e.g. 10.0 -> H=1, M=0, L=0)
 * ------------------------------------------------------------------------ */
void Affichage_voltage(void)
{
    int tmp;

    if (v_measured < 10.0f)
    {
        tmp     = (int)(v_measured * 100.0f + 0.5f);
        digit_H = tmp / 100;
        digit_M = (tmp / 10) % 10;
        digit_L = tmp % 10;
    }
    else
    {
        tmp     = (int)(v_measured * 10.0f + 0.5f);
        digit_H = tmp / 100;
        digit_M = (tmp / 10) % 10;
        digit_L = tmp % 10;
    }
}


/* --------------------------------------------------------------------------
 * Position_Point_Decimal_Voltage()
 * Select decimal-point position based on the magnitude of v_measured.
 *   < 10 V  -> point after digit H (X.XX)
 *   >= 10 V -> point after digit M (XX.X)
 * ------------------------------------------------------------------------ */
void Position_Point_Decimal_Voltage(void)
{
    dp_position = (v_measured < 10.0f) ? 0 : 1;
}


/* ==========================================================================
 * MODE HANDLERS
 * ========================================================================== */

/* --------------------------------------------------------------------------
 * MODE_VEILLE()
 * Blanks all segments and digit enables.
 * Called when no mode is active or when the hold timer expires.
 * ------------------------------------------------------------------------ */
void MODE_VEILLE(void)
{
    LATC = 0xFF;    /* all segments off (active-low) */
    LATE = 0xFF;    /* all digit enables off (active-low) */
}


/* --------------------------------------------------------------------------
 * MODE_HOLD()
 * Freezes the currently displayed value for exactly 3 seconds.
 * Loads hold_counter with HOLD_TICKS and sets mode = 3.
 * Multiplexage() decrements hold_counter on every timer ISR tick;
 * when it reaches 0 it transitions automatically to MODE_VEILLE.
 *
 * Called from the SW3 external-interrupt ISR in ext_int.c.
 * ------------------------------------------------------------------------ */
void MODE_HOLD(void)
{
    hold_counter = HOLD_TICKS;  /* load 3-second countdown */
    mode = 3;
}


/* --------------------------------------------------------------------------
 * MODE_OHMETRE()
 * Ohmmeter measurement on AN0.
 * Circuit: Vcc -- R_ref(100 k?) -- AN0 -- R_unknown -- GND
 * Formula: R_unknown = R_ref * V_AN0 / (Vcc - V_AN0)
 * Readings below 50 ? are out-of-range and displayed as 0.00.
 *
 * Called from main loop while mode == 2.
 * ------------------------------------------------------------------------ */
void MODE_OHMETRE(void)
{
    const float V_SUPPLY = 5.0f;
    const float R_REF    = 100000.0f;   /* reference resistor: 100 k? */
    float res_ohm_raw;

    adc_raw_ohm  = ADC_GetConversion(channel_AN0);
    v_divider    = V_SUPPLY * ((float)adc_raw_ohm / 1023.0f);
    res_ohm_raw  = (R_REF * v_divider) / (V_SUPPLY - v_divider);

    if (res_ohm_raw < 50.0f)
    {
        /* Out-of-range low: display 0.00 */
        digit_H = 0;
        digit_M = 0;
        digit_L = 0;
    }
    else
    {
        /* Convert ohms -> kohms, then split into display digits */
        res_kohm = res_ohm_raw / 1000.0f;
        Affichage_sur_chaque_digit();
        Position_Point_Decimal();
    }
}


/* --------------------------------------------------------------------------
 * MODE_VOLTMETRE()
 * Voltmeter measurement on AN1.
 * The external voltage-divider attenuates the input by ~2.052x;
 * this factor is applied in reverse to recover the true voltage.
 * Result is clamped to 10.00 V (display full-scale).
 *
 * Called from main loop while mode == 1.
 * ------------------------------------------------------------------------ */
void MODE_VOLTMETRE(void)
{
    const float V_REF = 5.0f;
    const float SCALE = 2.052f;     /* inverse of the input divider ratio */

    adc_raw_volt = (float)ADC_GetConversion(channel_AN1);
    v_measured   = (V_REF * adc_raw_volt / 1023.0f) * SCALE;

    if (v_measured > 10.0f)
        v_measured = 10.0f;         /* clamp to display maximum */

    Affichage_voltage();
    Position_Point_Decimal_Voltage();
}