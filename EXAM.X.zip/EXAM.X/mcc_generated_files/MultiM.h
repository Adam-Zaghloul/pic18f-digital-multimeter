/*
 * File:   MultiM.h
 * Author: Adam Zaghloul, Guy Arnold
 *
 * Created on April 13, 2026, 8:00 PM
 *
 * Multimetre numerique — PIC18F46K22
 * All files are inside MCC Generated Files/, so mcc.h is a sibling include.
 */

#ifndef MULTIM_H
#define MULTIM_H

#include <xc.h>
#include <stdint.h>
#include <math.h>
#include "mcc.h"

/* ==========================================================================
 * HOLD TIMER CONSTANT
 *
 * HOLD_TICKS = 3000 ms / TMR0_period_ms
 *
 * Adjust this value to match your TMR0 configuration in MCC.
 * Examples:
 *   TMR0 period =  1 ms  ->  HOLD_TICKS = 3000
 *   TMR0 period =  2 ms  ->  HOLD_TICKS = 1500
 *   TMR0 period =  5 ms  ->  HOLD_TICKS =  600
 * ========================================================================== */
#define HOLD_TICKS  1500u

/* ==========================================================================
 * GLOBAL VARIABLE DECLARATIONS
 * ========================================================================== */

/* 7-segment lookup table (common-anode, active-low, index 0-9) */
extern uint8_t TabSeg[];

/* Active mode selector (written by ISRs):
 *   0 = veille | 1 = voltmetre | 2 = ohmetre | 3 = hold */
extern volatile uint8_t mode;

/* Hold countdown — decremented each TMR0 ISR tick by Multiplexage() */
extern volatile uint16_t hold_counter;

/* Display digits: most significant (H), middle (M), least significant (L) */
extern int digit_H, digit_M, digit_L;

/* Decimal-point position: 0 = after digit H, 1 = after digit M */
extern int dp_position;

/* Ohmmeter intermediates */
extern uint16_t adc_raw_ohm;   /* raw 10-bit ADC reading on AN0 */
extern float    v_divider;     /* voltage at divider midpoint (V) */
extern float    res_kohm;      /* resistance in kohms (display value) */

/* Voltmeter intermediates */
extern float adc_raw_volt;     /* raw ADC reading (as float) */
extern float v_measured;       /* scaled true voltage (V) */


/* ==========================================================================
 * FUNCTION PROTOTYPES
 * (ordered by layer: display primitives -> helpers -> mode handlers)
 * ========================================================================== */

/* Display primitives */
void digitSelect(int digit);
void Multiplexage(void);

/* Digit decomposition helpers */
void Affichage_sur_chaque_digit(void);
void Position_Point_Decimal(void);
void Affichage_voltage(void);
void Position_Point_Decimal_Voltage(void);

/* Mode handlers */
void MODE_VEILLE(void);
void MODE_HOLD(void);
void MODE_OHMETRE(void);
void MODE_VOLTMETRE(void);

#endif /* MULTIM_H */
