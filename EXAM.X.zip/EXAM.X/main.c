/**
  Generated Main Source File
 
  Company:
    Microchip Technology Inc.
 
  File Name:
    main.c
 
  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs
 
  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC18F46K22
        Driver Version    :  2.00
*/
 
/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries.
    
    Subject to your compliance with these terms, you may use Microchip software and any
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party
    license terms applicable to your use of third party software (including open source software) that
    may accompany Microchip software.
   
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS
    FOR A PARTICULAR PURPOSE.
   
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS
    SOFTWARE.
*/
 
#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/MultiM.h"
#include <stdint.h>
#include <math.h>

/*
                         Main application
*/

void main(void)
{
    /* Initialize the device */
    SYSTEM_Initialize();
 
    /* Enable Global Interrupts */
    INTERRUPT_GlobalInterruptEnable();
 
    /* Enable Peripheral Interrupts */
    INTERRUPT_PeripheralInterruptEnable();
   
    /* Start the timer for display multiplexing */
    TMR0_StartTimer();
    TMR0_SetInterruptHandler(Multiplexage);
 
    /* Main loop ? respond to mode changes set by ISRs */
    while (1)
    {
        /* mode is set by external interrupt ISRs in ext_int.c */
        if (mode == 1)
        {
            /* Voltmetre mode */
            MODE_VOLTMETRE();
            __delay_ms(100);
        }
        else if (mode == 2)
        {
            /* Ohmetre mode */
            MODE_OHMETRE();
            __delay_ms(100);
        }
        else if (mode == 0 || mode == 3)
        {
            /* Veille (0) or Hold (3) ? display is managed by Multiplexage() ISR */
            /* No measurement needed; just let the timer keep the display refreshing */
        }
    }
}

/**
End of File
*/